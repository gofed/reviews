package scheduler

import (
	_ "github.com/mesos/mesos-go/auth/sasl"
	_ "github.com/mesos/mesos-go/auth/sasl/mech/crammd5"
	_ "github.com/mesos/mesos-go/detector/zoo"
)
