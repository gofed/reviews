package version
// AUTO-GENEREATED. DO NOT EDIT
// 2015-08-14 09:56:50.742727493 -0400 EDT

// VERSION is the generated version from /home/vbatts/src/vb/tar-split/version
var VERSION = "v0.9.6-1-gc76e420"
 