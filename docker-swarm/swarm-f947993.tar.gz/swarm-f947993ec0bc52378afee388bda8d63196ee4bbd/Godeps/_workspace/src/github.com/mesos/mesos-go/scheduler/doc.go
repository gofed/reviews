/*
Package scheduler includes the interfaces for the mesos scheduler and
the mesos executor driver.  It also contains as well as an implementation
of the driver that you can use in your code.
*/
package scheduler
